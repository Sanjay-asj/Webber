import StudentResult from "./StudentResults";
var Component4=()=>{
    return(<section>
        <h3>In Component 4</h3>
        <StudentResult/>
    </section>)
}
export default Component4;