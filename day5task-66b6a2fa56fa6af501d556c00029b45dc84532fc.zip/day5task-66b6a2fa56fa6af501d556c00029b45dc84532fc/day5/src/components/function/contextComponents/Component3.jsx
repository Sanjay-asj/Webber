import Component4 from "./Component4";
var Component3=()=>{
    return(<section>
        <h3>In Component 3</h3>
        <Component4/>
    </section>)
}
export default Component3;

