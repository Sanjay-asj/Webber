import Component3 from "./Component3";
//Component1 is your UseContext.jsx
var Component2=()=>{
    return(<section>
        <h3>In Component 2</h3>
        <Component3/>
    </section>)
}
export default Component2;