var ContextCompoment =()=>{
    return(
        <h1>This is an example of useContext</h1>
    ) ;  

}
    export default ContextCompoment ;