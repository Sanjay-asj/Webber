var UseMemo=()=>
{
    return(
        <section>
            <h1>Use memo</h1>
        </section>
    )
}
export default UseMemo;