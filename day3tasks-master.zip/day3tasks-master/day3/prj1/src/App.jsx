import './App.css'
import Class1 from './components/class/class1';

function App() {
 

  return (
   <div>
      <Class1/>
    </div>
      
    
  );
}

export default App;
  